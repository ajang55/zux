const {
  spawn
} = require("child_process");
const path = require("path");
function start() {
  let _0x31a0c1 = [path.join(__dirname, "servers/index.js"), ...process.argv.slice(0x2)];
  console.log([process.argv[0x0], ..._0x31a0c1].join("\n"));
  let _0x38da34 = spawn(process.argv[0x0], _0x31a0c1, {
    'stdio': ["inherit", "inherit", 'inherit', "ipc"]
  }).on("message", _0x53c70b => {
    if (_0x53c70b == "reset") {
      console.log("Restarting Bot...");
      _0x38da34.kill();
      start();
      delete _0x38da34;
    }
  }).on("exit", _0x34b2c0 => {
    console.error("Exited with code:", _0x34b2c0);
    if (_0x34b2c0 == '.' || _0x34b2c0 == 0x1 || _0x34b2c0 == 0x0) {
      start();
    }
  });
}
start();