require("../config");
const {
  default: LexxyBotConnect,
  delay,
  jidNormalizedUser,
  PHONENUMBER_MCC,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  getContentType,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  makeInMemoryStore,
  jidDecode,
  proto
} = require("@whiskeysockets/baileys");
const fs = require('fs');
const pino = require("pino");
const {
  join
} = require("path");
const {
  await,
  getBuffer,
  fetchJson
} = require("../lib/myfunc");
const makeWASocket = require('@whiskeysockets/baileys')["default"];
const readline = require("readline");
const NodeCache = require("node-cache");
const chalk = require("chalk");
const {
  color,
  mylog
} = require("../lib/color");
const store = makeInMemoryStore({
  'logger': pino().child({
    'level': 'silent',
    'stream': "store"
  })
});
let phoneNumber = global.botNumber;
autoread_sw = true;
const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code");
const useMobile = process.argv.includes('--mobile');
const xlec = readline.createInterface({
  'input': process.stdin,
  'output': process.stdout
});
const question = _0x5c745d => new Promise(_0x557589 => xlec.question(_0x5c745d, _0x557589));
async function connectToWhatsApp() {
  let {
    version: _0x4ebea0,
    isLatest: _0x460873
  } = await fetchLatestBaileysVersion();
  const {
    state: _0x5f37b6,
    saveCreds: _0x360f92
  } = await useMultiFileAuthState(join(__dirname, './session'));
  const _0x2006c9 = new NodeCache();
  const _0x400186 = makeWASocket({
    'logger': pino({
      'level': "silent"
    }),
    'printQRInTerminal': !pairingCode,
    'mobile': useMobile,
    'auth': {
      'creds': _0x5f37b6.creds,
      'keys': makeCacheableSignalKeyStore(_0x5f37b6.keys, pino({
        'level': 'fatal'
      }).child({
        'level': "fatal"
      }))
    },
    'browser': ['Ubuntu', "Chrome", "20.0.04"],
    'version': _0x4ebea0,
    'patchMessageBeforeSending': _0x31b508 => {
      const _0x5a2aa8 = !!(_0x31b508.buttonsMessage || _0x31b508.templateMessage || _0x31b508.listMessage);
      if (_0x5a2aa8) {
        _0x31b508 = {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': {
                'deviceListMetadataVersion': 0x2,
                'deviceListMetadata': {}
              },
              ..._0x31b508
            }
          }
        };
      }
      return _0x31b508;
    },
    'getMessage': async _0x556614 => {
      let _0xa7f473 = jidNormalizedUser(_0x556614.remoteJid);
      let _0x5e197a = await store.loadMessage(_0xa7f473, _0x556614.id);
      return _0x5e197a?.['message'] || '';
    },
    'markOnlineOnConnect': true,
    'generateHighQualityLinkPreview': true,
    'msgRetryCounterCache': _0x2006c9
  });
  store.bind(_0x400186.ev);
  if (pairingCode && !_0x400186.authState.creds.registered) {
    if (useMobile) {
      console.log("Cannot use pairing code with mobile api");
    }
    console.log(chalk.cyan("┌──────────────┈"));
    console.log("│• " + chalk.redBright("Silakan Tulis Nomor Whatsapp Anda"));
    console.log("│• " + chalk.redBright("Contoh : 628xxxxx"));
    console.log(chalk.cyan("└──────────────┈"));
    let _0x2af2ed;
    if (!!_0x2af2ed) {
      _0x2af2ed = _0x2af2ed.replace(/[^0-9]/g, '');
      if (!Object.keys(PHONENUMBER_MCC).some(_0x42431a => _0x2af2ed.startsWith(_0x42431a))) {
        console.log(chalk.bgBlack(chalk.redBright("Start with country code of your WhatsApp Number, Example : 628xxxxxxxx")));
        process.exit(0x0);
      }
    } else {
      _0x2af2ed = await question(chalk.bgBlack(chalk.greenBright("Your WhatsApp Number : ")));
      _0x2af2ed = _0x2af2ed.replace(/[^0-9]/g, '');
      if (!Object.keys(PHONENUMBER_MCC).some(_0x479e33 => _0x2af2ed.startsWith(_0x479e33))) {
        console.log(chalk.bgBlack(chalk.redBright("Start with country code of your WhatsApp Number, Example : 628xxxxxxxx")));
        _0x2af2ed = await question(chalk.bgBlack(chalk.greenBright("Your WhatsApp Number : ")));
        _0x2af2ed = _0x2af2ed.replace(/[^0-9]/g, '');
        xlec.close();
      }
    }
    setTimeout(async () => {
      let _0x8bfff = await _0x400186.requestPairingCode(_0x2af2ed);
      _0x8bfff = _0x8bfff?.["match"](/.{1,4}/g)?.["join"]('-') || _0x8bfff;
      console.log(chalk.bgBlack(chalk.greenBright("Copy Pairing Code :")), chalk.black(chalk.white(_0x8bfff)));
    }, 0x7d0);
  }
  _0x400186.ev.on("messages.upsert", async _0x30ed3c => {
    try {
      msg = _0x30ed3c.messages[0x0];
      if (!msg.message) {
        return;
      }
      require("../strava")(_0x400186, msg, store);
    } catch (_0x45b21d) {
      console.log(_0x45b21d);
    }
  });
  _0x400186.ev.on("connection.update", _0x24b71a => {
    console.log("Connection Update :", _0x24b71a);
    if (_0x24b71a.connection === "open") {
      console.log(mylog("Connected " + _0x400186.user.id));
    } else if (_0x24b71a.connection === 'close') {
      console.log(mylog('Disconnected!'));
      connectToWhatsApp();
    }
  });
  _0x400186.sendTextWithMentions = async (_0x2b001f, _0xc27d9b, _0x7f93e8, _0x2bb0cf = {}) => _0x400186.sendMessage(_0x2b001f, {
    'text': _0xc27d9b,
    'contextInfo': {
      'mentionedJid': [..._0xc27d9b.matchAll(/@(\d{0,16})/g)].map(_0x30e3b2 => _0x30e3b2[0x1] + '@s.whatsapp.net')
    },
    ..._0x2bb0cf
  }, {
    'quoted': _0x7f93e8
  });
  _0x400186.decodeJid = _0x309362 => {
    if (!_0x309362) {
      return _0x309362;
    }
    if (/:\d+@/gi.test(_0x309362)) {
      let _0x260cf4 = jidDecode(_0x309362) || {};
      return _0x260cf4.user && _0x260cf4.server && _0x260cf4.user + '@' + _0x260cf4.server || _0x309362;
    } else {
      return _0x309362;
    }
  };
  _0x400186.sendmentions = (_0x2f74e3, _0x2994bb, _0x494301 = [], _0x12b7c6) => {
    if (_0x12b7c6 == null || _0x12b7c6 == undefined || _0x12b7c6 == false) {
      let _0xe846a4 = _0x400186.sendMessage(_0x2f74e3, {
        'text': _0x2994bb,
        'mentions': _0x494301
      }, {
        'quoted': msg
      });
      return _0xe846a4;
    } else {
      let _0x45107f = _0x400186.sendMessage(_0x2f74e3, {
        'text': _0x2994bb,
        'mentions': _0x494301
      }, {
        'quoted': msg
      });
      return _0x45107f;
    }
  };
  _0x400186.ev.on("creds.update", _0x360f92);
  _0x400186.ev.process(async _0x2608f8 => {
    if (_0x2608f8["messages.upsert"]) {
      const _0x5810f5 = _0x2608f8["messages.upsert"];
      for (let _0x17b54b of _0x5810f5.messages) {
        if (_0x17b54b.key.remoteJid === "status@broadcast") {
          if (_0x17b54b.message?.["protocolMessage"]) {
            return;
          }
          await delay(0xbb8);
          if (autoread_sw) {
            await _0x400186.readMessages([_0x17b54b.key]);
          }
        }
      }
    }
  });
  return _0x400186;
}
connectToWhatsApp()["catch"](_0xb66dcf => console.log(_0xb66dcf));
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});